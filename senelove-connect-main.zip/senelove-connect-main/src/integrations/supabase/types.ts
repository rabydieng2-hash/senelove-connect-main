export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      children_summary: {
        Row: {
          age: number
          created_at: string
          gender: Database["public"]["Enums"]["gender"] | null
          id: string
          lives_with: Database["public"]["Enums"]["custody_situation"] | null
          profile_id: string
        }
        Insert: {
          age: number
          created_at?: string
          gender?: Database["public"]["Enums"]["gender"] | null
          id?: string
          lives_with?: Database["public"]["Enums"]["custody_situation"] | null
          profile_id: string
        }
        Update: {
          age?: number
          created_at?: string
          gender?: Database["public"]["Enums"]["gender"] | null
          id?: string
          lives_with?: Database["public"]["Enums"]["custody_situation"] | null
          profile_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "children_summary_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      partner_preferences: {
        Row: {
          accepts_children: boolean | null
          max_age: number | null
          min_age: number | null
          notes: string | null
          preferred_cities: string[] | null
          preferred_marital_status:
            | Database["public"]["Enums"]["marital_status"][]
            | null
          preferred_religions: string[] | null
          profile_id: string
          updated_at: string
        }
        Insert: {
          accepts_children?: boolean | null
          max_age?: number | null
          min_age?: number | null
          notes?: string | null
          preferred_cities?: string[] | null
          preferred_marital_status?:
            | Database["public"]["Enums"]["marital_status"][]
            | null
          preferred_religions?: string[] | null
          profile_id: string
          updated_at?: string
        }
        Update: {
          accepts_children?: boolean | null
          max_age?: number | null
          min_age?: number | null
          notes?: string | null
          preferred_cities?: string[] | null
          preferred_marital_status?:
            | Database["public"]["Enums"]["marital_status"][]
            | null
          preferred_religions?: string[] | null
          profile_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "partner_preferences_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          birth_date: string | null
          children_count: number | null
          city: string | null
          co_parenting_situation:
            | Database["public"]["Enums"]["custody_situation"]
            | null
          created_at: string
          education: string | null
          full_name: string | null
          gender: Database["public"]["Enums"]["gender"] | null
          id: string
          languages: string[] | null
          lifestyle: Json | null
          marital_status: Database["public"]["Enums"]["marital_status"] | null
          onboarding_completed: boolean | null
          phone_verified: boolean | null
          profession: string | null
          religion: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          birth_date?: string | null
          children_count?: number | null
          city?: string | null
          co_parenting_situation?:
            | Database["public"]["Enums"]["custody_situation"]
            | null
          created_at?: string
          education?: string | null
          full_name?: string | null
          gender?: Database["public"]["Enums"]["gender"] | null
          id: string
          languages?: string[] | null
          lifestyle?: Json | null
          marital_status?: Database["public"]["Enums"]["marital_status"] | null
          onboarding_completed?: boolean | null
          phone_verified?: boolean | null
          profession?: string | null
          religion?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          birth_date?: string | null
          children_count?: number | null
          city?: string | null
          co_parenting_situation?:
            | Database["public"]["Enums"]["custody_situation"]
            | null
          created_at?: string
          education?: string | null
          full_name?: string | null
          gender?: Database["public"]["Enums"]["gender"] | null
          id?: string
          languages?: string[] | null
          lifestyle?: Json | null
          marital_status?: Database["public"]["Enums"]["marital_status"] | null
          onboarding_completed?: boolean | null
          phone_verified?: boolean | null
          profession?: string | null
          religion?: string | null
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      custody_situation: "full" | "shared" | "partial" | "none"
      gender: "male" | "female"
      marital_status: "divorced" | "widowed" | "separated"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      custody_situation: ["full", "shared", "partial", "none"],
      gender: ["male", "female"],
      marital_status: ["divorced", "widowed", "separated"],
    },
  },
} as const
