import { useEffect, useState } from "react";
import { SunLogo } from "@/components/SunLogo";
import { useNavigate, Link } from "react-router-dom";
import { z } from "zod";
import { Heart, Mail, Lock, User as UserIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";

const emailSchema = z.string().trim().email("Adresse e-mail invalide").max(255);
const passwordSchema = z.string().min(8, "Minimum 8 caractères").max(72);
const nameSchema = z.string().trim().min(2, "Nom trop court").max(100);

export default function Auth() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && user) navigate("/onboarding", { replace: true });
  }, [user, loading, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      emailSchema.parse(email);
      passwordSchema.parse(password);
      if (mode === "signup") nameSchema.parse(fullName);
    } catch (err) {
      if (err instanceof z.ZodError) {
        toast({ title: "Vérifiez vos infos", description: err.errors[0].message, variant: "destructive" });
        return;
      }
    }

    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: {
            emailRedirectTo: `${window.location.origin}/onboarding`,
            data: { full_name: fullName },
          },
        });
        if (error) throw error;
        toast({ title: "Compte créé", description: "Bienvenue sur Yeesal 💛" });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Erreur inconnue";
      toast({ title: "Échec", description: msg, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const handleGoogle = async () => {
    setBusy(true);
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: `${window.location.origin}/onboarding` });
    if (result.error) {
      toast({ title: "Échec Google", description: String(result.error), variant: "destructive" });
      setBusy(false);
    }
  };

  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-sunset px-4 py-12">
      <div className="w-full max-w-md">
        <Link to="/" className="flex items-center justify-center gap-2.5 mb-6">
          <SunLogo size={44} />
          <span className="font-display text-2xl font-semibold">Yee<span className="text-primary">sal</span></span>
        </Link>

        <div className="bg-card rounded-3xl shadow-elegant p-7 border border-border">
          <h1 className="font-display text-2xl font-semibold text-center">Recommencez avec confiance</h1>
          <p className="text-sm text-muted-foreground text-center mt-1">Rejoignez la communauté des parents solos.</p>

          <Tabs value={mode} onValueChange={(v) => setMode(v as "signin" | "signup")} className="mt-6">
            <TabsList className="grid grid-cols-2 w-full">
              <TabsTrigger value="signup">Inscription</TabsTrigger>
              <TabsTrigger value="signin">Connexion</TabsTrigger>
            </TabsList>

            <form onSubmit={handleSubmit} className="space-y-4 mt-6">
              {mode === "signup" && (
                <div className="space-y-1.5">
                  <Label htmlFor="name">Nom complet</Label>
                  <div className="relative">
                    <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="name" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Aïssatou Diop" className="pl-9" required maxLength={100} />
                  </div>
                </div>
              )}
              <div className="space-y-1.5">
                <Label htmlFor="email">E-mail</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="vous@exemple.sn" className="pl-9" required />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="password">Mot de passe</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="8 caractères minimum" className="pl-9" required />
                </div>
              </div>

              <Button type="submit" variant="hero" size="lg" className="w-full" disabled={busy}>
                {busy ? "Patientez..." : mode === "signup" ? "Créer mon compte" : "Se connecter"}
              </Button>
            </form>

            <div className="relative my-5">
              <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border" /></div>
              <div className="relative flex justify-center text-xs uppercase"><span className="bg-card px-2 text-muted-foreground">ou</span></div>
            </div>

            <Button type="button" variant="outline" size="lg" className="w-full" onClick={handleGoogle} disabled={busy}>
              <svg className="h-4 w-4" viewBox="0 0 24 24"><path fill="#EA4335" d="M12 5c1.6 0 3 .55 4.1 1.45l3.05-3.05C17.4 1.85 14.9 1 12 1 7.3 1 3.3 3.7 1.4 7.6l3.55 2.75C5.9 7.35 8.7 5 12 5z"/><path fill="#4285F4" d="M23 12.27c0-.8-.08-1.55-.22-2.27H12v4.5h6.2c-.27 1.4-1.07 2.6-2.27 3.4l3.5 2.7c2.05-1.9 3.57-4.7 3.57-8.33z"/><path fill="#FBBC05" d="M4.95 14.35A6.85 6.85 0 014.6 12c0-.82.14-1.6.38-2.35L1.4 6.9A11 11 0 001 12c0 1.8.43 3.5 1.18 5l3.77-2.65z"/><path fill="#34A853" d="M12 23c2.95 0 5.43-.97 7.23-2.65l-3.5-2.7c-.97.65-2.2 1.05-3.73 1.05-3.3 0-6.1-2.35-7.05-5.5L1.4 16C3.3 19.9 7.3 23 12 23z"/></svg>
              Continuer avec Google
            </Button>
          </Tabs>
        </div>
      </div>
    </main>
  );
}
