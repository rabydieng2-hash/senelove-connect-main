
-- Enums
CREATE TYPE public.marital_status AS ENUM ('divorced', 'widowed', 'separated');
CREATE TYPE public.gender AS ENUM ('male', 'female');
CREATE TYPE public.custody_situation AS ENUM ('full', 'shared', 'partial', 'none');

-- Profiles
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  birth_date DATE,
  gender public.gender,
  city TEXT,
  languages TEXT[] DEFAULT '{}',
  marital_status public.marital_status,
  religion TEXT,
  education TEXT,
  profession TEXT,
  bio TEXT,
  avatar_url TEXT,
  children_count INT DEFAULT 0,
  co_parenting_situation public.custody_situation,
  lifestyle JSONB DEFAULT '{}'::jsonb,
  phone_verified BOOLEAN DEFAULT false,
  onboarding_completed BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view profiles"
  ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can delete own profile"
  ON public.profiles FOR DELETE TO authenticated USING (auth.uid() = id);

-- Children summary
CREATE TABLE public.children_summary (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  age INT NOT NULL,
  gender public.gender,
  lives_with public.custody_situation,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.children_summary TO authenticated;
GRANT ALL ON public.children_summary TO service_role;
ALTER TABLE public.children_summary ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view children"
  ON public.children_summary FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users manage own children"
  ON public.children_summary FOR ALL TO authenticated
  USING (auth.uid() = profile_id) WITH CHECK (auth.uid() = profile_id);

-- Partner preferences
CREATE TABLE public.partner_preferences (
  profile_id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  min_age INT DEFAULT 25,
  max_age INT DEFAULT 60,
  preferred_cities TEXT[] DEFAULT '{}',
  preferred_religions TEXT[] DEFAULT '{}',
  accepts_children BOOLEAN DEFAULT true,
  preferred_marital_status public.marital_status[] DEFAULT '{}',
  notes TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.partner_preferences TO authenticated;
GRANT ALL ON public.partner_preferences TO service_role;
ALTER TABLE public.partner_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own preferences"
  ON public.partner_preferences FOR SELECT TO authenticated USING (auth.uid() = profile_id);
CREATE POLICY "Users manage own preferences"
  ON public.partner_preferences FOR ALL TO authenticated
  USING (auth.uid() = profile_id) WITH CHECK (auth.uid() = profile_id);

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_prefs_updated BEFORE UPDATE ON public.partner_preferences
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', ''));
  INSERT INTO public.partner_preferences (profile_id) VALUES (NEW.id);
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
